struct node
{
    int number;

    int x;
    int y;
    bool been = false;

    bool operator ==(node a)
    {
        return this->number == a.number && this->x == a.x && this->y == a.y;
    }
};