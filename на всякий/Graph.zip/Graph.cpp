#include "Graph.h"

Graph::Graph()
{
    node start_node;
    start_node.number = count_of_nodes;
    start_node.x = 0;
    start_node.y = 0;
    start_node.been = true;

    count_of_nodes++;

    graph.push_back(start_node);

    current_node = 0;
}

void Graph::add_node(int x, int y, bool is_current)
{
    int index;
    index = get_node(x, y);
    if(index == -1)
    {
        node temp_node;

        temp_node.number = count_of_nodes;
        temp_node.x = x;
        temp_node.y = y;

        graph.push_back(temp_node);

        make_connection(temp_node.number, graph[current_node].number);
        // graph[count_of_nodes].connect(&graph[current_node]);
        // graph[current_node].connect(&graph[count_of_nodes]);
        count_of_nodes++;

        if(is_current) 
        {
            graph[graph.size() - 1].been = true;
            current_node = graph.size() - 1;
        }
    }
    else 
    {
        make_connection(graph[index].number, graph[current_node].number);
        if(is_current) 
        {
            graph[index].been = true;
            current_node = index;
        }
    }
}

void Graph::make_connection(int n1, int n2)
{
    graph_connection[n1][n2] = true;
    graph_connection[n2][n1] = true;
}

Vec<node> Graph::find_path(node to)
{
    int st = graph[current_node].number;
    int fn = to.number;

    Vec<node> exit;

    if(fn != -1)
    {
        Vec<Vec<int>> g;

        for (int i = 0; i < count_of_nodes; i++)
        {
            g.push_back(Vec<int>());
            for(int j = 0; j < count_of_nodes; j++)
            {
                if(graph_connection[i][j])
                {
                    g[i].push_back(j);
                }
            }
        }

        Queue q;
        q.push(st);
        Vec<bool> used(count_of_nodes);
        Vec<int> p(count_of_nodes);
        used[st] = true;
        p[st] = -1;
        while (!q.empty()) 
        {
            int v = q.front();
            q.pop();
            for (size_t i = 0; i < g[v].size(); ++i) 
            {
                int to = g[v][i];
                if (!used[to]) 
                {
                    used[to] = true;
                    q.push (to);
                    p[to] = v;
                }
            }
        }

        Vec<int> path;
        int past = fn;
        for (int i = 0; i < count_of_nodes; i++)
        {
            if(past != -1) 
            {
                path.push_back(past);
                past = p[past];
            }
        }

        // std::reverse(path.begin(), path.end());

        int n = path.size();
        for (int i = 0; i < n; i++)
        {
            exit.push_back(graph[path[n - i - 1]]);
        }
    }

    return exit;
}

bool Graph::get_node_exist(int x, int y)
{
    if(get_node(x, y) != -1) return true;
    else return false;
}

int Graph::get_node(int x, int y)
{
	int c = 0;
	int l = -1;
	int r = graph.size();
	while(r - l > 1)
	{
		c = (l + r)/2;
		if(graph[c].x >= x && graph[c].y >= y)
		{
			r = c;
		}
		else
		{
			l = c;
		}
	}

	if(graph[r].x == x && graph[r].y == y) return r;
    else return -1;
}

node Graph::get_not_been()
{
    int x = graph[current_node].x, y = graph[current_node].y;
    int x_c = 500, y_c = 500, index = 0;
    int x_vec_1, y_vec_1, x_vec_2, y_vec_2, len_1, len_2;
    for(int i = 0; i < count_of_nodes; i++)
    {
        x_vec_1 = abs(x - x_c);
        y_vec_1 = abs(y - y_c);
        x_vec_2 = abs(x - graph[i].x);
        y_vec_2 = abs(y - graph[i].y);
        len_1 = sqrt(x_vec_1*x_vec_1 + y_vec_1*y_vec_1);
        len_2 = sqrt(x_vec_2*x_vec_2 + y_vec_2*y_vec_2);
        if(graph[i].been == false && len_1 > len_2)
        {
            x_c = graph[i].x;
            y_c = graph[i].y;
            index = i;
        }
    }

    return graph[index];
}

Vec<node> Graph::get_graph()
{
    return graph;
}

node Graph::get_current_node()
{
    return graph[current_node];
}