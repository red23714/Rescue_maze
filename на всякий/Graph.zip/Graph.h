#pragma once

#include "Vec.h"
#include "Queue.h"
#include "Node.h"

class Graph
{
public:
    Graph();

    void add_node(int, int, bool = true);
    // void make_current_node();

    Vec<node> find_path(node);
    
    node get_not_been();
    bool is_been(int, int);
    bool get_node_exist(int, int);
    Vec<node> get_graph();
    node get_current_node();

private:
    Vec<node> graph;
    int count_of_nodes = 0;
    bool graph_connection[100][100]; 
    int current_node;

    int get_node(int, int);

    void make_connection(int, int);
};

