#pragma once

enum moves
{
    NO_MOVE = 0,
    ROTATE_RIGHT,
    ROTATE_LEFT,
    MOVE_FORWARD
};
