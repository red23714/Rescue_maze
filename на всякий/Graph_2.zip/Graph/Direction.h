#pragma once

enum direction
{
    NONE = 0,
    RIGHT,
    LEFT,
    FORWARD,
    BACKWARD
};